﻿Imports System.IO
Public Class Form1
    Private ex As Object
    ' Return True if another instance
    ' of this program is already running.
    Private Function AlreadyRunning() As Boolean
        ' Get our process name.
        Dim my_proc As Process = Process.GetCurrentProcess
        Dim my_name As String = my_proc.ProcessName

        ' Get information about processes with this name.
        Dim procs() As Process =
        Process.GetProcessesByName(my_name)

        ' If there is only one, it's us.
        If procs.Length = 1 Then Return False

        ' If there is more than one process,
        ' see if one has a StartTime before ours.
        Dim i As Integer
        For i = 0 To procs.Length - 1
            If procs(i).StartTime < my_proc.StartTime Then _
            Return True
        Next i

        ' If we get here, we were first.
        Return False
    End Function

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Application.ExitThread()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If AlreadyRunning() Then
            MessageBox.Show("The " & Application.ProductName & " " &
                     "application is already running, you do not need to run another instance of the program!" _
                     , Application.ProductName, MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation)
            Me.Close()
        End If

        Me.Text = Application.ProductName
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Process.Start(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "mingw32.exe"))
            'Application.ExitThread()
        Catch ex As Exception
            MessageBox.Show("Core program(s) are either missing or incompatible with thare either computer, Please update the MSYS2 toolchain with 'pacman -Su' and/or with 'pacman -syu' in the console.", Application.ProductName)
        End Try
        Application.ExitThread()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Process.Start(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "mingw64.exe"))
            'Application.ExitThread()
        Catch ex As Exception
            MessageBox.Show("Core program(s) are either missing or incompatible with this computer, Please update the MSYS2 toolchain with 'pacman -Su' and/or with 'pacman -syu' in the console.", Application.ProductName)
        End Try
        Application.ExitThread()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            Process.Start(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "clang64.exe"))
            'Application.ExitThread()
        Catch ex As Exception
            MessageBox.Show("Core program(s) are either missing or incompatible with this computer, Please update the MSYS2 toolchain with 'pacman -Su' and/or with 'pacman -syu' in the MSYS2 console.", Application.ProductName)
        End Try
        Application.ExitThread()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Process.Start(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ucrt64.exe"))
            'Application.ExitThread()
        Catch ex As Exception
            MessageBox.Show("Core program(s) is missing or incompatible with this computer, Please update the MSYS2 toolchain with 'pacman -Su' and/or with 'pacman -syu' in the console.", Application.ProductName)
        End Try
        Application.ExitThread()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Try
            Process.Start(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "msys2.exe"))
            'Application.ExitThread()
        Catch ex As Exception
            MessageBox.Show("Core program(s) is missing or incompatible with this computer, Please update MSYS2 toolchain with 'pacman -Su' and/or with 'pacman -syu' in the console.", Application.ProductName)
        End Try
        Application.ExitThread()
    End Sub
End Class
